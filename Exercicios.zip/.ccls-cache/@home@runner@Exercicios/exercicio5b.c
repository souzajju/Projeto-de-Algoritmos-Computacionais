//

int voo (int hp, int hr, int mp, int mr)
{
  int voo1, voo2, diferenca;
  voo1= horario (hp, mp);
  voo2= horario (hr, mr);
  diferenca= voo2- voo1;
  return diferenca;
}
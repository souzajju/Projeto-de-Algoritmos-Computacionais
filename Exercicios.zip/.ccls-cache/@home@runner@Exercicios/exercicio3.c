// Faca uma função que receba como parâmetros o preço unitário de um produto. Esta função deverá calcular e retornar o novo preço unitário considerando que houve um aumento de 20% no preço unitário.

float novo_preco (float preco)
{
  float novo;
  novo= preco* 1.2;
  return novo;
}
// Faca uma função que receba como parâmetros as 2 notas de um aluno (valores reais), calcula e retrone a média aritmética.

float calcula_media (float n1, float n2)
{
  float media;
  media= (n1+n2)/2;
  return media;
}
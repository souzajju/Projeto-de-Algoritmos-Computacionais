//Faca a função calculaValor que receba como parâmetros o valor do litro de um combustivel (numero real) e a quantidade de litros abastecida por um cliente (numero real). Afunção deverá calculcar e exibir o valor a ser pago.

void calculaValor (float litro, float qntd)
{
  float valor;
  valor=litro* qntd;
  printf("O valor é: %f", valor);
}
#include <stdio.h>

void quantidadeCelular (int valor)
{ int qntd100, qntd50, qntd20, qntd10, qntd5,qntd2, qntd1, qntdT;
  qntd100 = valor/100;
  valor = valor%100;
  qntd50 = valor/50;
  valor= valor%50;
  qntd20 = valor/20;
  valor= valor%20;
 qntd10= valor/10;
 valor= valor%10;
 qntd5= valor/5;
 valor= valor%5;
  qntd2= valor/2;
 valor= valor%2;
 qntd1= valor/1;
 valor= valor%1;
 qntdT= qntd100 + qntd50 + qntd20 + qntd10 + qntd5 + qntd2 + qntd1;
 printf("A menor quantidade e: %d", qntdT);
 
}
//Faça uma função que receba como parâmetro o número de dias decorrido em um evento e exiba o mesmo valor expresso em números de semanas e número de dias. Por exemplo, se o número de dias decorrido em um evento for o valor 19, a funçãodeve exibir: “2 semanas e 5 dias”.
#include <stdio.h>
void calcula_dias (int d)
{
  int semanas, dias;
  semanas= d/7;
  dias=d%7;
  printf("%d semanas e %d dias", semanas, dias);
}
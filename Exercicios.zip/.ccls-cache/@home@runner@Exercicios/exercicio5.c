//Faça uma função que receba como parâmetros dois números inteiros: horas e minutos. Esta função deverá retornar o horário convertido em minutos.
//A
int horario(int h, int m)
{
  int total;
  hora= h*60+ m;
  return total;
}

//B
int voo (int hp, int hr, int mp, int mr)
{
  int voo1, voo2, diferenca;
  voo1= horario (hp, mp);
  voo2= horario (hr, mr);
  diferenca= voo2- voo1;
  return diferenca;
}